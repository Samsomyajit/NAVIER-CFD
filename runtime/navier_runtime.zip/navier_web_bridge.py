from __future__ import annotations

import inspect
import json
import pkgutil
from dataclasses import fields, is_dataclass, replace
from enum import Enum
from typing import Any, get_args, get_origin, get_type_hints

from navier_cfd import Catalog, TaskSpec, recommend_models
from navier_cfd.evidence import EvidenceRecord
from navier_cfd.runtime_registry import NATIVE_REFERENCE_MODEL_IDS
import navier_cfd.recommender as _recommender_module

_CATALOG = Catalog.load_builtin()
_CATALOG.models = [
    replace(model, integration="native")
    if model.id in NATIVE_REFERENCE_MODEL_IDS
    else model
    for model in _CATALOG.models
]
_EVIDENCE_BYTES = pkgutil.get_data("navier_cfd", "data/paper_evidence.json")
if _EVIDENCE_BYTES is None:
    raise RuntimeError("NAVIER-CFD paper evidence catalog is missing from the browser runtime")
_EVIDENCE = tuple(
    EvidenceRecord.from_dict(row)
    for row in json.loads(_EVIDENCE_BYTES.decode("utf-8"))
)
# The normal loader uses a filesystem Path. The browser package is zip-imported,
# so provide the same immutable evidence records directly to the recommender.
_recommender_module.load_builtin_evidence = lambda: _EVIDENCE


def _jsonable(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {field.name: _jsonable(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list, set, frozenset)):
        return [_jsonable(item) for item in value]
    return value


def _coerce(annotation: Any, value: Any) -> Any:
    if value is None:
        return None
    origin = get_origin(annotation)
    args = get_args(annotation)
    if origin is not None:
        if origin in (list, tuple, set, frozenset):
            item_type = args[0] if args else Any
            values = value if isinstance(value, (list, tuple, set)) else [value]
            converted = [_coerce(item_type, item) for item in values]
            return origin(converted) if origin is not tuple else tuple(converted)
        if origin is dict:
            return value
        for candidate in args:
            if candidate is type(None):
                continue
            try:
                return _coerce(candidate, value)
            except (TypeError, ValueError):
                pass
        return value
    try:
        if inspect.isclass(annotation) and issubclass(annotation, Enum):
            return annotation(value)
    except TypeError:
        pass
    if annotation is bool:
        return value if isinstance(value, bool) else str(value).lower() in {"1", "true", "yes", "on"}
    if annotation in (int, float, str):
        return annotation(value)
    return value


def _build_task(raw: dict[str, Any]) -> TaskSpec:
    aliases = {
        "conservation": "requires_conservation",
        "uncertainty": "requires_uncertainty",
        "long_rollout": "requires_long_rollout",
        "geometry_transfer": "requires_geometry_transfer",
        "mesh_transfer": "requires_mesh_transfer",
        "memory_gb": "hardware_memory_gb",
    }
    raw = {aliases.get(key, key): value for key, value in raw.items()}
    hints = get_type_hints(TaskSpec)
    kwargs: dict[str, Any] = {}
    for field in fields(TaskSpec):
        if field.name in raw and raw[field.name] not in ("", None):
            kwargs[field.name] = _coerce(hints.get(field.name, field.type), raw[field.name])
    return TaskSpec(**kwargs)


def recommend_json(task_json: str, top_k: int = 8) -> str:
    task = _build_task(json.loads(task_json))
    ranked = recommend_models(task, _CATALOG.models, top_k=int(top_k))
    return json.dumps([_jsonable(item) for item in ranked])


def health_json() -> str:
    return json.dumps({
        "engine": "navier_cfd.recommender",
        "models": len(_CATALOG.models),
        "native_reference_models": len(NATIVE_REFERENCE_MODEL_IDS),
        "datasets": len(_CATALOG.datasets),
        "evidence_records": len(_EVIDENCE),
        "status": "ready",
    })
